# ---------------------------
# IMPORTS
# ---------------------------
import streamlit as st                     # Streamlit library for building the web app UI
import requests                            # Requests library for making HTTP API calls
import pandas as pd                        # Pandas for handling tabular data (dataframes, excel export, etc.)
import io                                  # IO module for handling in-memory file operations
import time                                # Time module for delays, retries, and timeouts
from collections import deque              # Deque for efficient queue operations (used for failed API calls)
import json                                # JSON library for reading/writing memory data
import os                                  # OS library to interact with filesystem (check if files exist, etc.)
import numpy as np                         # Numpy for numerical operations
from sklearn.base import BaseEstimator, TransformerMixin  # Base classes to create custom transformers
import joblib                              # Joblib for saving/loading trained ML models or pipelines
from bs4 import BeautifulSoup              # BeautifulSoup for scraping and parsing HTML pages
from datetime import datetime              # Datetime for handling timestamps and dates
from dotenv import load_dotenv 
from transformers import AutoTokenizer, AutoModelForSequenceClassification
import torch

# ---------------------------
# CONFIGURATION
# ---------------------------
load_dotenv()

SERPAPI_KEY = os.getenv("SERPAPI_KEY") # API key for SerpAPI


MEMORY_FILE = "esg_agent_memory.json"    # File used to store the agent's memory (to avoid reprocessing same articles)



# The class EmbeddingTransformer are required to load the saved 
# pipeline (esg_pipeline.pkl) because the pipeline was trained using them as steps. 
# While they are not called directly in the code, Python needs their definitions to reconstruct 
# the objects during unpickling. 
# Removing it would prevent the pipeline from loading correctly.




# ---------------------------
# CACHED MODEL LOADING
# ---------------------------


# from sentence_transformers import SentenceTransformer   # Import SentenceTransformer for embeddings
# from sklearn.base import BaseEstimator, TransformerMixin
 
# class EmbeddingTransformer(BaseEstimator, TransformerMixin):   # Custom transformer for embeddings
#     def __init__(self, model_path):            # Initialize with path to model
#         self.model_path = model_path
#         self.model = SentenceTransformer(model_path)   # Load pretrained embedding model
 
#     def fit(self, X, y=None):                  # Fit (no-op here)
#         return self
 
#     def transform(self, X):                    # Encode texts into embeddings
#         return self.model.encode(X, show_progress_bar=False)




# @st.cache_resource(show_spinner=True)          # Cache the pipeline loading in Streamlit to avoid reloading every time
# def load_esg_pipeline():
#     pipeline = joblib.load("esg_pipeline.pkl") # Load trained ML pipeline (classification + embedding)
#     return pipeline

# pipeline = load_esg_pipeline()                 # Load the pipeline 


@st.cache_resource(show_spinner=True)
def load_esg_model():
    model_path = r"C:/Users/chrys/Downloads/project/project/best_distilbert_esg"
    
    from transformers import AutoTokenizer, AutoModelForSequenceClassification
    
    tokenizer = AutoTokenizer.from_pretrained(model_path, local_files_only=True)
    model = AutoModelForSequenceClassification.from_pretrained(model_path, local_files_only=True)
    
    return tokenizer, model

# Load the model
tokenizer, model = load_esg_model()






# ---------------------------
# ESG KEYWORDS FLAT
# ---------------------------
ESG_KEYWORDS_FLAT = [   # List of flat ESG-related keywords for search queries
    "climate","emissions","carbon","pollution","renewable","sustainability","waste",
    "recycling","energy","water","deforestation","environmental impact","conservation",
    "diversity","equality","inclusion","human rights","labor","workplace","employee",
    "community","safety","ethics","fair trade","social responsibility","welfare",
    "child labor","working conditions","governance","board","audit","compliance",
    "corruption","transparency","anti-bribery","shareholder","accountability",
    "executive pay","risk management","corporate responsibility", "Gasoline Emissions",
    "Methane Emissions"
]

def extract_full_text(url):    # Function to extract full text from an article URL
    """Try to fetch and extract the main article text from a URL."""
    try:
        resp = requests.get(url, timeout=10)   # Make HTTP request
        if resp.status_code != 200:           # If request fails
            return ""
        soup = BeautifulSoup(resp.text, "html.parser")   # Parse HTML page

        # Strategy: collect all <p> tags, join them
        paragraphs = [p.get_text() for p in soup.find_all("p")]   # Extract all paragraph texts
        text = " ".join(paragraphs)   # Join paragraphs into one text

        return text.strip()           # Return clean text
    except Exception as e:            # In case of failure
        print(f"Failed to extract full text from {url}: {e}")
        return ""

# ---------------------------
# FETCH FUNCTIONS
# ---------------------------


def fetch_serpapi_articles(company, target_n=100):     # Fetch articles from SerpAPI
    esg_query = "(" + " OR ".join(ESG_KEYWORDS_FLAT) + ")"
    query = f'"{company}" AND {esg_query}'
    url = f"https://serpapi.com/search.json?q={query}+ESG&engine=google_news&api_key={SERPAPI_KEY}&num={target_n}"
    try:
        data = requests.get(url).json()   # API call
    except:
        return []
    all_articles = []
    for item in data.get("news_results", []):   # Parse results
        content = (item.get("snippet") or "")
        all_articles.append({   # Store fields
            "company": company,
            "title": item.get("title",""),
            "description": item.get("snippet",""),
            "content": content,
            "url": item.get("link",""),
            "source": item.get("source","Unknown"),
            "publishedAt": item.get("date",""),
            "esg_label": None,
            "esg_score": None
        })
    #print(f"[SERPAPI] Retrieved {len(all_articles)} articles for {company}")  
    return all_articles


# ---------------------------
# ESG Agent Class
# ---------------------------
class ESGAgent:    # Define the ESG Agent class
    PAYWALL_PATTERNS = ["/premium/", "/subscribe/", "ft.com/content/", "wsj.com/articles/", "bloomberg.com/news/articles"]  # Patterns for paywalled sites

    def __init__(self, clf, embedder, memory_file=MEMORY_FILE, max_retries=3):   # Constructor
        self.clf = clf
        self.embedder = embedder
        self.memory_file = memory_file
        self.memory = self.load_memory()   # Load memory from file
        self.failed_calls = deque()        # Track failed API calls
        self.max_retries = max_retries     # Retry limit

    def load_memory(self):    # Load memory from JSON file
        if os.path.exists(self.memory_file):
            with open(self.memory_file, "r", encoding="utf-8") as f:
                return json.load(f)
        return {}

    def save_memory(self):    # Save memory to JSON file
        with open(self.memory_file, "w", encoding="utf-8") as f:
            json.dump(self.memory, f, indent=2)

    def plan_fetch(self, company, target_total=200):   # Plan which sources to use
        return [
            
            {"fetch_func": fetch_serpapi_articles, "n": target_total//4},
            
        ]

    def execute_fetch(self, fetch_func, company, n):   # Execute fetching with retries
        attempts = 0
        while attempts < self.max_retries:
            try:
                articles = fetch_func(company, target_n=n)
                new_articles = [a for a in articles if a['url'] not in self.memory]   # Filter already seen
                for art in new_articles:
                    self.memory[art['url']] = art   # Save in memory
                return new_articles
            except Exception:
                attempts += 1
                time.sleep(2 ** attempts)           # Exponential backoff
                self.failed_calls.append((fetch_func, company, n))
        return []

    def is_paywalled_article(self, url):   # Detect if article is paywalled
        try:
            if any(p in url.lower() for p in self.PAYWALL_PATTERNS):   # Check URL patterns
                return True
            resp = requests.get(url, timeout=5)
            soup = BeautifulSoup(resp.text, "html.parser")
            text = soup.get_text().lower()
            if "paywall" in text or len(text) < 200:   # If paywall detected
                return True
            return False
        except:
            return True

    def analyze_article(self, article, esg_keywords_flat):   # Analyze an article
        full_text = extract_full_text(article.get("url", ""))   # Try to get full text

        if full_text:
            text = full_text
        else:
            text = ((article.get("title","") or "") + " " +
                    (article.get("description","") or "") + " " +
                    (article.get("content","") or "")).strip()

        #print("text: " + text[:400]) 

        if not text:
            return None

        # Generate predictions with classifier
        tokenizer, model = self.clf
        inputs = tokenizer(text, return_tensors="pt", truncation=True, padding=True, max_length=512)
        with torch.no_grad():
            outputs = model(**inputs)
            logits = outputs.logits
            preds = (logits > 0).int().tolist()[0]   # assumes multi-label classification (E, S, G)

        #print(preds)
        e, s, g = preds
        paywalled = self.is_paywalled_article(article.get("url",""))

        return {   # Return structured result
            "Company": article.get("company","Unknown"),
            "Title": article.get("title",""),
            "Source": article.get("source","Unknown"),
            "Published": article.get("publishedAt",""),
            "E": int(e),
            "S": int(s),
            "G": int(g),
            "Paywalled": paywalled,
            "URL": article.get("url",""),
            "Article Text": text
        }

    def run(self, companies, target_total=200, esg_keywords_flat=[]):   # Run ESG analysis for companies
        all_results = []
        for company in companies:   # Loop through companies
            plan = self.plan_fetch(company, target_total)   # Get fetch plan
            for step in plan:
                fetch_func = step["fetch_func"]
                n = step["n"]
                articles = self.execute_fetch(fetch_func, company, n)   # Fetch articles
                for art in articles:
                    result = self.analyze_article(art, esg_keywords_flat)   # Analyze each article
                    if result:
                        all_results.append(result)
        self.save_memory()   # Save updated memory
        return all_results   # Return results

# ---------------------------
# STREAMLIT APP
# ---------------------------
st.set_page_config(page_title="ESG Agent", page_icon="🌍", layout="wide")  # Configure Streamlit page title, icon, and layout
st.title("🌍 ESG Company Agent")  # Set the main title of the app
st.write("Enter a list of company names (comma-separated) for ESG analysis.")  # Instruction text for the user

# Sidebar settings
st.sidebar.header("⚙️ Settings")  # Header for the sidebar section

paywall_filter = st.sidebar.selectbox(  # Create a dropdown in the sidebar for paywall filter options
    "Paywalled Articles",                # Label for the dropdown
    ["Include All", "Exclude Paywalled", "Only Paywalled"]  # Options: include all, exclude paywalled, or only paywalled
)

target_articles = st.sidebar.slider(  # Create a slider in the sidebar to select number of articles per company
    "Number of Articles per Company",  # Label for the slider
    min_value=50,                      # Minimum slider value
    max_value=500,                     # Maximum slider value
    value=200,                         # Default value
    step=50,                           # Step size for the slider
    key="article_slider"               # Unique key to avoid Streamlit duplicate element errors
)

# Company input
company_input = st.text_input("Enter company names (comma-separated)")  # Text input for the user to enter companies
companies = [c.strip() for c in company_input.split(",") if c.strip()]  # Split input by commas, remove extra spaces, ignore empty strings

if st.button("Analyze"):  # Trigger analysis when user clicks the "Analyze" button
    if not SERPAPI_KEY:  # Check if all API keys are set
        st.error("Please set all API keys!")  # Show error if any key is missing
    elif companies:  # Proceed only if there are valid company names entered
        agent = ESGAgent(clf=(tokenizer, model), embedder=None)  # Initialize ESGAgent with the loaded ML pipeline
        with st.spinner("Fetching and analyzing articles..."):  # Show spinner while fetching and analyzing
            results = agent.run(  # Run the ESGAgent on the entered companies
                companies,  # List of companies
                target_total=target_articles,  # Number of articles to fetch per company
                esg_keywords_flat=ESG_KEYWORDS_FLAT  # ESG keywords to use for analysis
            )
        
        if results:  # If any articles are returned
            st.success(f"Analyzed {len(results)} articles for {len(companies)} companies!")  # Show success message
            df = pd.DataFrame(results)  # Convert results list of dictionaries into a Pandas DataFrame

            # Apply paywall filter
            if paywall_filter == "Exclude Paywalled":  # If user wants to exclude paywalled articles
                df = df[df["Paywalled"] == False]  # Keep only non-paywalled articles
            elif paywall_filter == "Only Paywalled":  # If user wants only paywalled articles
                df = df[df["Paywalled"] == True]  # Keep only paywalled articles

            # Display plain table
            st.write("### 📰 Articles Table")  # Section header for the articles table
            st.dataframe(df[["Company", "Title", "Source", "Published", "E", "S", "G", "Paywalled"]])  # Show relevant columns in the table

            # Export Excel
            output = io.BytesIO()  
            df.to_excel(output, index=False, engine="openpyxl")  # Export DataFrame to Excel in memory
            output.seek(0)  # Reset buffer pointer to the beginning
            st.download_button(  # Create a download button for the Excel file
                "Download Excel Report",  # Button text
                data=output,  # Excel file data
                file_name=f"esg_analysis_multi.xlsx",  # Default file name
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"  # MIME type for Excel
            )

            # ESG Visualizations
            st.write("## 📊 ESG Visualizations")  # Section header for visualizations
            esg_counts = {  # Count total ESG flags in all articles
                "Environment (E)": df["E"].sum(),  # Total Environmental flags
                "Social (S)": df["S"].sum(),       # Total Social flags
                "Governance (G)": df["G"].sum()    # Total Governance flags
            }
            st.bar_chart(pd.Series(esg_counts))  # Display a bar chart of ESG counts

        else:  # If no valid articles are found
            st.warning("No valid articles found.")  # Show a warning message
